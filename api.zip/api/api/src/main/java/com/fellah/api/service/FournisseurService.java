package com.fellah.api.service;
import java.util.List;

import com.fellah.api.model.Fournisseur;
public interface FournisseurService {
	 public Fournisseur saveFournisseur(Fournisseur fournisseur);
	    public List<Fournisseur> getAllFournisseurs();
	  /*  public Fournisseur update(Long id);
	    public void delete(int id);*/
}







